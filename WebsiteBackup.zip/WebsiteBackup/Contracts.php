<!DOCTYPE html>
<html>
<head>
	<title>Contracts</title>
		<meta charset="utf-8">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<link rel="stylesheet" type="text/css" href="style.css">
		<link rel="stylesheet" href="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css">
		<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
		<script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>
	
	<ul>
	<li><a href="homepage.php">Home</a></li>
    <li><a href="newjobs.php">New Jobs</a></li>
	<li><a href="Contracts.php">Contracts</a></li>
	<li><a href="customersearch.php">Customer Search</a></li>
	<li><a href="bidcalculator.php">Bid Calculator</a></li>
    <li><a href="partsedit.php">Parts Edit</a></li>
	</ul>
	
</head>

<body>
<div class="background">
		<div class="transbox">
	<link rel="stylesheet" type="text/css" href="style.css">
	<h1>Contracts</h1>
	<div id="status"></div>
	
	<!--
	<div id="button">
	<center><a href="newjobs.php"><button id="showData">New Jobs</button></a></center>
    <center><button id="showData">Customer Name Search</button></center>
    <center><button id="showData">Customer Address Search</button></center>
    <center><button id="showData">Job ID Search</button></center>
	</div>	
    -->
    
    <div id="forms">   
 <center>
 <form action="thankyoucontract.php" method="post">
 <p>
<br>
 <input type="text" name="Contract_Price" placeholder="Contract Price" required>
 <br>
<br>
 <input type="email" name="Contract_opt1" placeholder="Contract Option 1" required>
 <br>
 <br>
 <input type="text" name="Contract_opt2" placeholder="Contract Option 2" required>
 <br>
<br>
<input type="text" name="Contract_opt" placeholder="Contract Option" required>
<br>
<br>
<input type="text" name="Contract_Extra" placeholder="Contract Extra" required>
<br>
<center><font color= white>Contract Job Status:</font></center><br>
<input type="text" name="Bid_Job_Status" required>
<br>
<input type="submit" value="Submit">
<br>
</form>
</p></center>    
 </div>
	
</body>
</div>
</div>
</html>